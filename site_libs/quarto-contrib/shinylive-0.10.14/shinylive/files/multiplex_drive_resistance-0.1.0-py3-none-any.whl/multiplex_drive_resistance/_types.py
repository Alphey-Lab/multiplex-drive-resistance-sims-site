"""Shared result types for the multiplex drive resistance simulations."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

import numpy as np

__all__ = ["SimulationResult"]


@dataclass
class SimulationResult:
    """Container for the outputs of a single simulation run.

    Attributes
    ----------
    resistance:
        ``1`` if the resistance/test allele(s) reached ``test_threshold`` in
        both sexes before the population was eliminated or ``T`` generations
        elapsed, otherwise ``0``.
    N_end:
        Total population size (males + females) at the final recorded
        generation.
    tau:
        The generation index (0-based) of the final recorded time point.
    x:
        Array of shape ``(num_alleles, n_generations)`` with the frequency of
        each allele among males at each recorded generation.
    y:
        Array of shape ``(num_alleles, n_generations)`` with the frequency of
        each allele among females at each recorded generation.
    t:
        Array of shape ``(n_generations,)`` with the generation indices
        corresponding to the columns of ``x`` and ``y``.
    M, F, N:
        Male, female and total population sizes at each recorded generation.
    wm, wf:
        Mean male and female fitness at each recorded generation.
    z:
        Array of shape ``(2 * num_alleles, n_generations)`` with the combined
        population-level (not on the simplex) male/female allele frequency
        vector at each recorded generation.
    """

    resistance: int
    N_end: float
    tau: int
    x: np.ndarray
    y: np.ndarray
    t: np.ndarray
    M: Optional[np.ndarray] = field(default=None)
    F: Optional[np.ndarray] = field(default=None)
    N: Optional[np.ndarray] = field(default=None)
    wm: Optional[np.ndarray] = field(default=None)
    wf: Optional[np.ndarray] = field(default=None)
    z: Optional[np.ndarray] = field(default=None)
