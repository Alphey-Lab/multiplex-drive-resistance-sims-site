"""Hybrid Poisson-Gaussian approximation to the multinomial distribution.

This is a Python port of ``GaussPoissonHybrid_mnrnd.m`` from the original
MATLAB reference implementation
(https://github.com/BhavKhatri/MutliplexDriveResistanceSims).

For small totals (``N < 1000``) an exact multinomial draw is used. For large
totals, alleles whose expected count (``N * x[i]``) is below a threshold are
drawn independently from a Poisson distribution (since their contribution to
the overall covariance structure is negligible), while alleles with larger
expected counts are drawn jointly from a multivariate normal approximation to
the multinomial distribution, which is both fast and accurate for large
counts. The multivariate-normal draw is resampled until it is non-negative
and does not exceed the number of remaining individuals, and the result is
rounded to the nearest integer while the very last "large" allele absorbs the
remainder so the output always sums exactly to ``N``.
"""

from __future__ import annotations

import numpy as np

__all__ = ["gauss_poisson_hybrid_mnrnd", "allele_variance_matrix"]

# Numerical tolerance used when checking that probabilities sum to one.
_PROB_SUM_TOL = 1e-8

# Threshold (in expected count units) below which an allele is treated with
# a Poisson approximation rather than folded into the joint Gaussian draw.
_DEFAULT_NTHR = 10


def allele_variance_matrix(x: np.ndarray) -> np.ndarray:
    """Build the multinomial covariance matrix for (non-simplex) frequencies ``x``.

    ``B[j, k] = x[j] * (1 - x[j])`` on the diagonal and ``B[j, k] = -x[j] * x[k]``
    off the diagonal, matching MATLAB's ``AlleleVarianceMatrix``.
    """
    x = np.asarray(x, dtype=float)
    outer = np.outer(x, x)
    B = -outer
    np.fill_diagonal(B, x * (1.0 - x))
    return B


def gauss_poisson_hybrid_mnrnd(
    N: int,
    x: np.ndarray,
    rng: np.random.Generator,
    nthr: float = _DEFAULT_NTHR,
) -> np.ndarray:
    """Draw a hybrid Poisson-Gaussian approximate multinomial sample.

    Parameters
    ----------
    N:
        Total count to distribute (must be a non-negative integer).
    x:
        Probability vector (must be non-negative and sum to 1).
    rng:
        A ``numpy.random.Generator`` instance used for all randomness, to
        keep sampling reproducible and free of global random state.
    nthr:
        Expected-count threshold below which an allele is drawn from a
        Poisson distribution rather than jointly with the other "large"
        alleles.

    Returns
    -------
    numpy.ndarray
        Integer array of the same length as ``x`` whose entries sum to ``N``.
    """
    x = np.asarray(x, dtype=float)

    if N < 0 or float(N) != round(N):
        raise ValueError("N must be a non-negative integer")
    if np.any(x < 0):
        raise ValueError("Error: frequency vector must not have negative entries")
    if abs(x.sum() - 1.0) > _PROB_SUM_TOL:
        raise ValueError("Error: elements of frequency vector must sum to 1")

    N = int(round(N))
    K = x.shape[0]

    if N < 1000:
        return rng.multinomial(N, x)

    # Order frequencies from small to large, recording the original ordering
    # so results can be reverted at the end (mirrors MATLAB's use of `sort`
    # to avoid numerical issues with large dynamic range in mvnrnd).
    order = np.argsort(x, kind="stable")
    xs = x[order]

    n_sorted = np.zeros(K, dtype=np.int64)

    Nx = N * xs
    small_mask = (Nx <= nthr) & (xs != 0)
    small_idx = np.flatnonzero(small_mask)
    large_idx = np.flatnonzero(Nx > nthr)

    if small_idx.size > 0:
        n_sorted[small_idx] = rng.poisson(Nx[small_idx])

    nsum = int(n_sorted[small_idx].sum()) if small_idx.size > 0 else 0
    NN = N - nsum

    if large_idx.size > 1:
        large_main = large_idx[:-1]
        large_last = large_idx[-1]

        # Conditional frequencies within the "large" subset -- deliberately
        # *not* renormalised onto the simplex (matches the MATLAB code).
        xx = xs[large_main] / xs[large_idx].sum()

        B = NN * allele_variance_matrix(xx)
        mu = NN * xx

        _max_retries = 1000
        nn = rng.multivariate_normal(mu, B)
        _retries = 0
        while (nn.sum() > NN or np.any(nn < 0)) and _retries < _max_retries:
            nn = rng.multivariate_normal(mu, B)
            _retries += 1
        if _retries >= _max_retries:
            # Gaussian approximation failed to converge; fall back to exact
            # multinomial sampling to guarantee valid output.
            return rng.multinomial(N, p).astype(np.int64)

        nn = np.round(nn).astype(np.int64)
        n_sorted[large_main] = nn
        n_sorted[large_last] = NN - int(nn.sum())
    elif large_idx.size == 1:
        n_sorted[large_idx[0]] = NN
    else:
        # No "large" alleles -- everything was handled by the Poisson draws
        # above. Any residual rounding difference (NN != 0) is assigned to
        # the allele with the largest probability to guarantee the output
        # sums exactly to N.
        if NN != 0:
            n_sorted[-1] += NN

    # Revert back to the original order of indexing.
    n = np.empty(K, dtype=np.int64)
    n[order] = n_sorted
    return n
