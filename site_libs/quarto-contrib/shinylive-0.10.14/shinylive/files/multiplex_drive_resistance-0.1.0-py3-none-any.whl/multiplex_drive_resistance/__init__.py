"""Multiplex Drive Resistance Simulations - Python port of BhavKhatri/MutliplexDriveResistanceSims."""

from .models import simulate

__version__ = "0.1.0"
__all__ = ["simulate"]
