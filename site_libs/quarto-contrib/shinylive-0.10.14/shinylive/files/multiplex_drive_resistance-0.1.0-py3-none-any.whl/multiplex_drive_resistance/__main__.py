"""Command-line interface for running multiplex drive resistance simulations.

Usage::

    python -m multiplex_drive_resistance --model duplex --seed 42 \\
        --generations 200 --output-dir results/duplex-example
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import Optional, Sequence

import numpy as np

from .models import simulate

__all__ = ["main", "build_parser"]

_MODEL_CHOICES = ("single", "duplex", "triplex")
_MODEL_TO_M = {"single": 1, "duplex": 2, "triplex": 3}


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="multiplex-drive",
        description=(
            "Run a single stochastic Wright-Fisher simulation of multiplex "
            "target-site drive resistance."
        ),
    )
    parser.add_argument(
        "--model",
        choices=_MODEL_CHOICES,
        default="single",
        help="Which multiplex model to run (default: %(default)s).",
    )
    parser.add_argument("--seed", type=int, default=None, help="Random seed.")
    parser.add_argument(
        "--generations", "-T", type=int, default=200,
        help="Number of generations to simulate (default: %(default)s).",
    )
    parser.add_argument(
        "--output-dir", type=Path, default=None,
        help="Directory to write results (allele frequencies, population "
        "sizes) to as a .npz file. If omitted, a short summary is printed.",
    )

    # Biological parameters, with defaults matching the reference MATLAB
    # example scripts.
    parser.add_argument("--s", type=float, default=0.9, help="Fitness cost of D/D, N/N (females).")
    parser.add_argument("--h", type=float, default=0.1, help="Dominance coeff. of W/D heterozygote.")
    parser.add_argument("--hN", type=float, default=0.1, help="Dominance coeff. of W/N heterozygote.")
    parser.add_argument("--sigma", type=float, default=0.05, help="Fitness cost of R allele.")
    parser.add_argument("--Rm", type=float, default=6.0, help="Intrinsic population growth rate.")
    parser.add_argument("--K", type=float, default=10000.0, help="Carrying capacity.")
    parser.add_argument("--xD", type=float, default=0.1, help="Initial male drive frequency.")
    parser.add_argument("--yD", type=float, default=0.1, help="Initial female drive frequency.")
    parser.add_argument("--epsilon", type=float, default=0.95, help="Drive cleavage efficiency.")
    parser.add_argument("--nu", type=float, default=0.02, help="NHEJ rate per generation.")
    parser.add_argument("--mu", type=float, default=1e-8, help="Point mutation rate.")
    parser.add_argument("--beta", type=float, default=0.5, help="Fraction of resistant NHEJ mutations.")
    parser.add_argument("--xi", type=float, default=0.1, help="Fraction of resistant point mutations.")
    parser.add_argument(
        "--preexisting", action="store_true",
        help="Run a burn-in period to establish mutation-selection balance before introducing drive.",
    )
    parser.add_argument(
        "--no-gauss", dest="gauss", action="store_false",
        help="Disable the hybrid Poisson-Gaussian multinomial approximation "
        "(always draw an exact multinomial sample).",
    )
    parser.set_defaults(gauss=True)

    return parser


def main(argv: Optional[Sequence[str]] = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    m = _MODEL_TO_M[args.model]

    result = simulate(
        m=m,
        s=args.s,
        h=args.h,
        hN=args.hN,
        sigma=args.sigma,
        Rm=args.Rm,
        K=args.K,
        xD=args.xD,
        yD=args.yD,
        epsilon=args.epsilon,
        nu=args.nu,
        mu=args.mu,
        beta=args.beta,
        xi=args.xi,
        preexisting=args.preexisting,
        T=args.generations,
        Gauss=args.gauss,
        seed=args.seed,
    )

    if args.output_dir is not None:
        args.output_dir.mkdir(parents=True, exist_ok=True)
        out_file = args.output_dir / f"{args.model}_result.npz"
        np.savez(
            out_file,
            x=result.x,
            y=result.y,
            t=result.t,
            N=result.N,
            M=result.M,
            F=result.F,
            resistance=result.resistance,
            N_end=result.N_end,
            tau=result.tau,
        )
        print(f"Wrote results to {out_file}")
    else:
        print(f"model = {args.model}")
        print(f"resistance = {result.resistance}")
        print(f"N_end = {result.N_end}")
        print(f"tau = {result.tau}")

    return 0


if __name__ == "__main__":
    sys.exit(main())
