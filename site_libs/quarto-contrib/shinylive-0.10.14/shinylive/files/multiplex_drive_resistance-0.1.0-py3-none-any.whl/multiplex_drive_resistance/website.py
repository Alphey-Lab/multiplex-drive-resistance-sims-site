"""Helpers for the minimal Quarto interactive website."""

from __future__ import annotations

from typing import Dict, List

import numpy as np

from ._types import SimulationResult
from .models._common import ordered_tuples

__all__ = [
    "DEFAULT_PARAMETERS",
    "DEFAULT_SEED",
    "combined_frequency_trajectory",
    "haplotype_labels",
    "result_summary",
]


DEFAULT_PARAMETERS: Dict[str, float | bool | int] = {
    "s": 0.9,
    "h": 0.1,
    "hN": 0.1,
    "sigma": 0.05,
    "Rm": 6.0,
    "K": 10_000.0,
    "xD": 0.1,
    "yD": 0.1,
    "epsilon": 0.95,
    "nu": 0.02,
    "mu": 1e-8,
    "beta": 0.5,
    "xi": 0.1,
    "preexisting": True,
    "T": 200,
}
DEFAULT_SEED = 42

_BASE_LABELS = {0: "W", 1: "R", 2: "N"}


def haplotype_labels(m: int) -> List[str]:
    """Return the ordered allele/haplotype labels for multiplex level ``m``."""
    if m not in (1, 2, 3):
        raise ValueError(f"Unsupported multiplex level m={m!r}; expected 1, 2 or 3")

    if m == 1:
        return ["W", "R", "N", "D"]

    labels = ["".join(_BASE_LABELS[idx] for idx in haplotype) for haplotype in ordered_tuples(3, m)]
    labels.append("D" * m)
    return labels


def combined_frequency_trajectory(result: SimulationResult) -> np.ndarray:
    """Population-weighted allele/haplotype frequencies across generations."""
    if result.M is None or result.F is None or result.N is None:
        raise ValueError("SimulationResult must include M, F and N trajectories")

    combined = np.zeros_like(result.x, dtype=float)
    positive = result.N > 0
    if np.any(positive):
        combined[:, positive] = (
            result.x[:, positive] * result.M[positive] + result.y[:, positive] * result.F[positive]
        ) / result.N[positive]
    return combined


def result_summary(result: SimulationResult) -> Dict[str, bool | float | int]:
    """Return a compact summary for display in the website."""
    return {
        "resistance_established": bool(result.resistance),
        "final_population_size": float(result.N_end),
        "final_generation": int(result.tau),
    }
