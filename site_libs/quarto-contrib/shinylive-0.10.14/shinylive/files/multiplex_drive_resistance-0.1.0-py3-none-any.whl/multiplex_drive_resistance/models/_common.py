"""Shared helpers for building generic m-plex ("multiplex") super-allele models.

The MATLAB reference implementation has separate files for the duplex
(``TargetSiteResistance_Duplex_4Allelle.m``) and triplex
(``TargetSiteResistance_Triplex_4Allelle.m``) cases which independently
construct super-allele (haplotype) orderings, genotype fitness matrices,
mutation kernels and drive-stoichiometry matrices. Both files build these
objects using the same underlying combinatorial recipe, generalised in the
triplex file's comments to arbitrary multiplex level ``m``. This module
implements that recipe once, for arbitrary ``m``, and is used by both
:mod:`multiplex_drive_resistance.models.duplex` and
:mod:`multiplex_drive_resistance.models.triplex` (and is numerically
equivalent to the single-locus formulas hard-coded in
``TargetSiteResistance_4Allelle.m`` when ``m == 1``).

Base (single target-site) alleles are indexed 0=W (wild-type), 1=R
(functional resistant), 2=N (non-functional resistant). Each of the ``ns``
super-alleles (haplotypes) is a non-decreasing tuple of ``m`` base-allele
indices, e.g. for ``m=2``: (W,W), (W,R), (R,R), (W,N), (R,N), (N,N) -- in
that order, matching the MATLAB super-allele ordering -- plus one additional
super-allele (always the *last*, at index ``ns - 1``) representing the fully
drive-converted haplotype (e.g. DD, DDD).
"""

from __future__ import annotations

import itertools
import math
from dataclasses import dataclass
from typing import List, Tuple

import numpy as np

__all__ = [
    "sum_tensor_diagonal",
    "ordered_tuples",
    "symmetrize_tensor",
    "MultiplexModel",
    "build_multiplex_model",
    "preexisting_burnin_frequencies",
]

# Base allele indices (0-based) at a single target site, excluding drive.
_W, _R, _N = 0, 1, 2


def sum_tensor_diagonal(n: int, m: int) -> int:
    """Number of unordered ``m``-combinations with repetition from ``n`` symbols.

    Matches MATLAB's ``SumTensorDiagonal(n, m) = gamma(n + m) / (gamma(n) * m!)``.
    """
    return math.comb(n + m - 1, m)


def ordered_tuples(n: int, m: int) -> List[Tuple[int, ...]]:
    """Generate all ``m``-tuples ``(i_1 <= i_2 <= ... <= i_m)``, ``i_k`` in
    ``[0, n - 1]``, in the same order as the MATLAB reference code's
    column-major "upper diagonal" construction (``ind2sub`` over an
    ``n**m``-sized array filtered to non-decreasing index tuples).

    For example ``ordered_tuples(3, 2)`` (alleles W=0, R=1, N=2) yields::

        (0,0) (0,1) (1,1) (0,2) (1,2) (2,2)   # WW WR RR WN RN NN

    which matches the duplex super-allele order, and ``ordered_tuples(3, 3)``
    matches the triplex super-allele order (WWW WWR WRR RRR WWN ... NNN).
    """

    def helper(bound: int, length: int):
        if length == 0:
            yield ()
            return
        for top in range(bound + 1):
            for rest in helper(top, length - 1):
                yield rest + (top,)

    return list(helper(n - 1, m))


def symmetrize_tensor(v: np.ndarray) -> np.ndarray:
    """Symmetrise a tensor by summing over *distinct* axis permutations.

    For an index tuple ``idx``, ``result[idx]`` equals the sum of ``v[p]``
    over each distinct permutation ``p`` of ``idx`` (repeated index values
    collapse to a single term). This matches the MATLAB reference code's
    ``Symmetrise3DTensor`` helper (and, for 2D arrays, its
    ``V + tril(V, -1)'`` idiom) which accounts for the fact that the
    haplotypes being modelled are unordered combinations of alleles across
    target sites, while the raw Kronecker-product tensor built from the
    per-site mutation/drive vectors is built with an arbitrary fixed axis
    order.
    """
    shape = v.shape
    result = np.zeros(shape, dtype=float)
    for idx in np.ndindex(shape):
        perms = set(itertools.permutations(idx))
        total = 0.0
        for p in perms:
            total += v[p]
        result[idx] = total
    return result


@dataclass
class MultiplexModel:
    """Container for a fully constructed generic m-plex super-allele model."""

    m: int
    ns: int
    haplotypes: List[Tuple[int, ...]]
    Wm: np.ndarray
    Wf: np.ndarray
    Mu: np.ndarray
    S: np.ndarray
    H: np.ndarray
    test_allele: List[int]


def _haplotype_allele_counts(tup: Tuple[int, ...]) -> Tuple[int, int, int]:
    """Count of W, R, N alleles (in that order) within a haplotype tuple."""
    return tup.count(_W), tup.count(_R), tup.count(_N)


def _build_fitness(
    m: int, s: float, h: float, hN: float, sigma: float
) -> Tuple[np.ndarray, np.ndarray, List[Tuple[int, ...]], int]:
    haplotypes = ordered_tuples(3, m)
    ns = len(haplotypes) + 1
    drive_idx = ns - 1

    nR = np.full(ns, np.nan)
    nW = np.zeros(ns)
    for i, tup in enumerate(haplotypes):
        nw, nr, nn = _haplotype_allele_counts(tup)
        if nn == 0:
            nR[i] = nr
            nW[i] = nw
        # else nR[i] stays NaN (haplotype contains a non-functional allele)

    hD = h
    Wf = np.zeros((ns, ns))
    Wm = np.ones((ns, ns))

    for i in range(ns):
        for j in range(ns):
            i_is_drive = i == drive_idx
            j_is_drive = j == drive_idx
            i_nan = np.isnan(nR[i])
            j_nan = np.isnan(nR[j])

            if i_is_drive or j_is_drive:
                # nR[drive_idx] is always NaN (the drive haplotype is never
                # assigned a finite nR above), so whenever i_is_drive is True,
                # i_nan is guaranteed True (symmetrically for j_is_drive /
                # j_nan). Hence at least one of i_nan/j_nan is always True
                # here and one of the three branches below always applies --
                # matching the MATLAB reference's equivalent if/elseif/elseif
                # block for the `i==ns || j==ns` case, which likewise has no
                # final else because the same invariant holds there.
                assert i_nan or j_nan
                if i_nan and j_nan:
                    Wf[i, j] = 1 - s
                elif i_nan:
                    if nW[j] == 0:
                        Wf[i, j] = (1 - sigma) ** nR[j] * (1 - hN * s)
                    else:
                        Wf[i, j] = (1 - sigma) ** nR[j] * (1 - hD * s)
                elif j_nan:
                    if nW[i] == 0:
                        Wf[i, j] = (1 - sigma) ** nR[i] * (1 - hN * s)
                    else:
                        Wf[i, j] = (1 - sigma) ** nR[i] * (1 - hD * s)
            else:
                if i_nan and j_nan:
                    Wf[i, j] = 1 - s
                elif i_nan:
                    Wf[i, j] = (1 - sigma) ** nR[j] * (1 - hN * s)
                elif j_nan:
                    Wf[i, j] = (1 - sigma) ** nR[i] * (1 - hN * s)
                else:
                    Wf[i, j] = (1 - sigma) ** nR[i] * (1 - sigma) ** nR[j]

    return Wm, Wf, haplotypes, ns


def _build_mutation(m: int, mu: float, xi: float, haplotypes: List[Tuple[int, ...]], ns: int) -> np.ndarray:
    muvec = np.array([1 - mu, xi * mu, (1 - xi) * mu])  # W -> W, R, N
    uR = np.array([0.0, 1.0, 0.0])
    uN = np.array([0.0, 0.0, 1.0])
    base_vectors = {_W: muvec, _R: uR, _N: uN}

    M = np.zeros((ns, ns))
    for col, tup in enumerate(haplotypes):
        v = np.array([1.0])
        for allele in tup:
            v = np.kron(v, base_vectors[allele])
        v = v.reshape((3,) * m)
        v = symmetrize_tensor(v)
        for row, out_tup in enumerate(haplotypes):
            M[row, col] = v[out_tup]

    drive_idx = ns - 1
    M[drive_idx, drive_idx] = 1.0  # drive always transmits drive

    return M - np.eye(ns)


def _build_stoichiometry(
    m: int, epsilon: float, nu: float, beta: float, haplotypes: List[Tuple[int, ...]], ns: int
) -> Tuple[np.ndarray, np.ndarray, List[int]]:
    drive_idx = ns - 1

    kappa = np.array(
        [1 - epsilon, epsilon * nu * beta, epsilon * nu * (1 - beta), epsilon * (1 - nu)]
    )
    kR = np.array([0.0, 1.0, 0.0, 0.0])
    kN = np.array([0.0, 0.0, 1.0, 0.0])
    base_vectors = {_W: kappa, _R: kR, _N: kN}

    haplotypes4 = ordered_tuples(4, m)  # over W,R,N,D alphabet, sorted ascending
    drive_symbol = 3

    S = np.zeros((ns, ns))
    for col, tup in enumerate(haplotypes):
        v = np.array([1.0])
        for allele in tup:
            v = np.kron(v, base_vectors[allele])
        v = v.reshape((4,) * m)
        v = symmetrize_tensor(v)

        sd = sum(v[t] for t in haplotypes4 if drive_symbol in t)

        slicer = (slice(0, 3),) * m
        v_wrn = v[slicer]
        col_vec = np.array([v_wrn[t] for t in haplotypes])
        col_vec = np.append(col_vec, sd)
        S[:, col] = col_vec

    S[drive_idx, drive_idx] = 1.0
    S = S - np.eye(ns)

    nonzero_cols = np.flatnonzero(np.any(S != 0, axis=0))
    H = np.vstack([nonzero_cols, np.full(nonzero_cols.shape, drive_idx)])
    S_reduced = S[:, nonzero_cols]

    test_allele = [i for i in range(ns - 1) if i not in set(nonzero_cols.tolist())]

    return S_reduced, H, test_allele


def build_multiplex_model(
    m: int,
    s: float,
    h: float,
    hN: float,
    sigma: float,
    epsilon: float,
    nu: float,
    mu: float,
    beta: float,
    xi: float,
) -> MultiplexModel:
    """Build the full generic m-plex super-allele model.

    Returns a :class:`MultiplexModel` with the male/female fitness matrices,
    mutation matrix, drive stoichiometry matrix, 0-based drive-heterozygote
    index array ``H``, and the (0-based) resistant "test allele" indices
    (haplotypes with no wild-type copy remaining, which drive therefore
    cannot act on).
    """
    Wm, Wf, haplotypes, ns = _build_fitness(m, s, h, hN, sigma)
    Mu = _build_mutation(m, mu, xi, haplotypes, ns)
    S, H, test_allele = _build_stoichiometry(m, epsilon, nu, beta, haplotypes, ns)

    return MultiplexModel(
        m=m,
        ns=ns,
        haplotypes=haplotypes,
        Wm=Wm,
        Wf=Wf,
        Mu=Mu,
        S=S,
        H=H,
        test_allele=test_allele,
    )


def preexisting_burnin_frequencies(
    Mu: np.ndarray, Wf: np.ndarray, ns: int
) -> Tuple[np.ndarray, np.ndarray]:
    """Approximate mutation-selection balance starting frequencies for the
    resistance-allele burn-in phase used by ``preexisting=True`` in the
    duplex/triplex reference models.

    This is only valid when the resistant haplotypes reachable from the
    all-wild-type haplotype (column 0 of ``Mu``) are sufficiently
    deleterious to remain at low frequency, and R alleles are additive
    (no dominance), matching the caveats documented in the MATLAB reference
    code.

    Returns ``(x0, indm)`` where ``x0`` is a length-``ns`` frequency vector
    (drive frequency fixed at zero) and ``indm`` is the array of haplotype
    indices with a non-zero one-step mutation rate from the wild-type
    haplotype (excluding the wild-type haplotype itself), which the caller
    should re-use to seed the final initial condition after the burn-in run.
    """
    indm_full = np.flatnonzero(Mu[:, 0])
    indm = indm_full[indm_full != 0]

    muin = Mu[indm, 0]
    # Uses row 0 (wild-type) of the *female* fitness matrix to approximate
    # the selection coefficient against each haplotype when heterozygous with
    # the wild-type. This is valid only when R alleles are additive
    # (dominance coefficient h≈0.5) and when Wf is approximately symmetric,
    # so that Wf[0, i] ≈ Wf[i, 0].  These assumptions match the linear
    # approximation documented in the MATLAB reference; they would need to be
    # revised for asymmetric or fully-dominant fitness models.
    f = np.diag((Wf[0, indm] - 1) / 2.0)
    MMu = Mu[np.ix_(indm, indm)]

    eq = -np.linalg.solve(MMu + f, muin)

    x0 = np.zeros(ns)
    x0[indm] = eq
    x0[ns - 1] = 0.0
    x0[0] = 1.0 - x0.sum()

    return x0, indm
