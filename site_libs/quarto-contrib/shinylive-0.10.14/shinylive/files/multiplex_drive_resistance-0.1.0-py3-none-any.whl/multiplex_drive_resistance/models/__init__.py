"""Model constructors for the multiplex drive resistance simulations.

This subpackage builds fitness/mutation/stoichiometry matrices for the
single-target-site ("singleplex"), duplex and triplex multiplex target-site
resistance models described in the MATLAB reference implementation
(https://github.com/BhavKhatri/MutliplexDriveResistanceSims), and dispatches
to the appropriate model via :func:`simulate`.
"""

from __future__ import annotations

from typing import Optional

import numpy as np

from .._types import SimulationResult
from . import duplex, singleplex, triplex

__all__ = ["simulate"]

_MODELS = {
    1: singleplex,
    2: duplex,
    3: triplex,
    "single": singleplex,
    "singleplex": singleplex,
    "duplex": duplex,
    "triplex": triplex,
}


def simulate(
    m: int,
    s: float,
    h: float,
    hN: float,
    sigma: float,
    Rm: float,
    K: float,
    xD: float,
    yD: float,
    epsilon: float,
    nu: float,
    mu: float,
    beta: float,
    xi: float,
    preexisting: bool,
    T: int,
    Gauss: bool = True,
    seed: Optional[int] = None,
    rng: Optional[np.random.Generator] = None,
) -> SimulationResult:
    """Dispatch to the singleplex (``m=1``), duplex (``m=2``) or triplex
    (``m=3``) multiplex target-site resistance model.

    Parameters follow the MATLAB reference functions
    ``TargetSiteResistance_4Allelle.m``,
    ``TargetSiteResistance_Duplex_4Allelle.m`` and
    ``TargetSiteResistance_Triplex_4Allelle.m``:

    s, h, hN, sigma
        Fitness-cost and dominance parameters (see module docstrings in
        :mod:`multiplex_drive_resistance.models.singleplex` for details).
    Rm
        Intrinsic population growth rate.
    K
        Carrying capacity (assuming an all-wild-type population).
    xD, yD
        Initial drive frequency in males and females respectively.
    epsilon, nu, mu, beta, xi
        Drive efficiency, NHEJ rate, mutation rate, NHEJ-resistant fraction,
        and point-mutation-resistant fraction.
    preexisting
        If true, run a burn-in period to establish mutation-selection
        balance of resistance alleles before introducing drive.
    T
        Number of generations to simulate.
    Gauss
        If true (default), use the hybrid Poisson-Gaussian approximate
        multinomial sampler for performance at large population sizes;
        if false, always draw an exact multinomial sample.
    seed, rng
        Supply either an integer seed (a fresh ``numpy.random.Generator``
        will be created) or an existing ``numpy.random.Generator`` instance.
        If neither is given, a non-deterministic default generator is used.
    """
    if m not in _MODELS:
        raise ValueError(f"Unsupported multiplex level m={m!r}; expected 1, 2 or 3")

    if rng is None:
        rng = np.random.default_rng(seed)

    module = _MODELS[m]
    return module.run(
        s=s,
        h=h,
        hN=hN,
        sigma=sigma,
        Rm=Rm,
        K=K,
        xD=xD,
        yD=yD,
        epsilon=epsilon,
        nu=nu,
        mu=mu,
        beta=beta,
        xi=xi,
        preexisting=preexisting,
        T=T,
        Gauss=Gauss,
        rng=rng,
    )
