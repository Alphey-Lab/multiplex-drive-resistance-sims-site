"""Duplex (2 gRNAs / target sites) multiplex target-site resistance model.

Python port of ``TargetSiteResistance_Duplex_4Allelle.m`` from the MATLAB
reference implementation
(https://github.com/BhavKhatri/MutliplexDriveResistanceSims).

Models 2 Cas9 target sites, each with 4 possible alleles (W, R, N, D), but
where a mosaic of drive on a single chromosome is not possible: gametes are
combinations of the 3 non-drive alleles across both sites (giving 6
super-alleles/haplotypes WW, WR, RR, WN, RN, NN), plus a single fully
drive-converted haplotype DD -- 7 super-alleles in total.
"""

from __future__ import annotations

import numpy as np

from .._types import SimulationResult
from ..simulation import simulate_core
from ._common import build_multiplex_model, preexisting_burnin_frequencies

__all__ = ["run"]

_M = 2


def run(
    s: float,
    h: float,
    hN: float,
    sigma: float,
    Rm: float,
    K: float,
    xD: float,
    yD: float,
    epsilon: float,
    nu: float,
    mu: float,
    beta: float,
    xi: float,
    preexisting: bool,
    T: int,
    Gauss: bool,
    rng: np.random.Generator,
) -> SimulationResult:
    """Run a single instance of the duplex target-site resistance model.

    Parameters mirror :func:`multiplex_drive_resistance.models.singleplex.run`,
    but ``epsilon``, ``nu`` and ``mu`` are per-target-site rates (each of the
    2 sites is subject to independent drive cleavage/NHEJ/mutation).
    """
    psi = 0.5
    test_threshold = 0.95
    alpha = K / (Rm - 1)

    model = build_multiplex_model(_M, s, h, hN, sigma, epsilon, nu, mu, beta, xi)
    Wm, Wf, Mu, S, H = model.Wm, model.Wf, model.Mu, model.S, model.H
    ns = model.ns
    test_allele = model.test_allele
    drive_idx = ns - 1

    if preexisting:
        x0, indm = preexisting_burnin_frequencies(Mu, Wf, ns)
        y0 = x0.copy()

        Tpre = round(1 / sigma)

        burn_in = simulate_core(
            ns, K, psi, x0, y0, Wm, Wf, Mu, S, H, Rm, alpha, Tpre, Gauss,
            test_allele, float("inf"), rng,
        )

        x0 = np.zeros(ns)
        y0 = np.zeros(ns)
        x0[indm] = burn_in.x[indm, -1]
        y0[indm] = burn_in.y[indm, -1]

        x0[drive_idx] = xD
        x0[0] = 1 - np.sum(x0)

        y0[drive_idx] = yD
        y0[0] = 1 - np.sum(y0)
    else:
        x0 = np.zeros(ns)
        y0 = np.zeros(ns)
        x0[drive_idx] = xD
        y0[drive_idx] = yD
        x0[0] = 1 - xD
        y0[0] = 1 - yD

    if np.any(x0 < 0) or np.any(y0 < 0):
        raise ValueError("Error: frequency vector must not have negative entries")

    result = simulate_core(
        ns, K, psi, x0, y0, Wm, Wf, Mu, S, H, Rm, alpha, T, Gauss,
        test_allele, test_threshold, rng,
    )

    return result
