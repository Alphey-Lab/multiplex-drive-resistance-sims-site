"""Singleplex (single gRNA / target site) target-site resistance model.

Python port of ``TargetSiteResistance_4Allelle.m`` from the MATLAB reference
implementation
(https://github.com/BhavKhatri/MutliplexDriveResistanceSims).

Models a single Cas9 target site with 4 alleles: W (wild-type), R
(functional resistant), N (non-functional resistant) and D (drive).
"""

from __future__ import annotations

import numpy as np

from .._types import SimulationResult
from ..simulation import simulate_core
from ._common import build_multiplex_model

__all__ = ["run"]

# Alleles are ordered W, R, N, D (matching the MATLAB reference).
_W, _R, _N, _D = 0, 1, 2, 3


def run(
    s: float,
    h: float,
    hN: float,
    sigma: float,
    Rm: float,
    K: float,
    xD: float,
    yD: float,
    epsilon: float,
    nu: float,
    mu: float,
    beta: float,
    xi: float,
    preexisting: bool,
    T: int,
    Gauss: bool,
    rng: np.random.Generator,
) -> SimulationResult:
    """Run a single instance of the singleplex target-site resistance model.

    Parameters
    ----------
    s:
        Fitness cost of homozygote D/D and N/N in females.
    h:
        Dominance coefficient/fitness cost of heterozygote W/D in females.
    hN:
        Dominance coefficient/fitness cost of heterozygote W/N in females.
    sigma:
        Fitness cost of the functional resistant heterozygote W/R (and half
        the fitness cost of R/R), in females.
    Rm:
        Intrinsic growth rate of the population, assuming it is all W.
    K:
        Carrying capacity of the population, assuming it is all W.
    xD, yD:
        Initial frequency of drive in males and females.
    epsilon:
        Efficiency of drive cleavage.
    nu:
        Non-homologous end-joining (NHEJ) rate per generation per individual.
    mu:
        Mutation rate per cleavage target site per generation per individual.
    beta:
        Fraction of functional resistant NHEJ mutations.
    xi:
        Fraction of functional resistant single-nucleotide mutations.
    preexisting:
        If true, run a burn-in period of ``round(1 / sigma)`` generations
        (without drive) to establish an approximate mutation-selection
        balance frequency of the R allele before introducing drive.
    T:
        Number of generations to simulate.
    Gauss:
        If true, use the hybrid Poisson-Gaussian approximate multinomial
        sampler; if false, always draw an exact multinomial sample.
    rng:
        A ``numpy.random.Generator`` used for all randomness.
    """
    psi = 0.5
    test_allele = [_R, _N]
    test_threshold = 0.95
    alpha = K / (Rm - 1)

    model = build_multiplex_model(1, s, h, hN, sigma, epsilon, nu, mu, beta, xi)
    Wm, Wf, Mu, S, H = model.Wm, model.Wf, model.Mu, model.S, model.H

    if preexisting:
        xR = xi * mu / (sigma / 2)
        yR = xi * mu / (sigma / 2)

        x0 = np.array([1 - xR, xR, 0.0, 0.0])
        y0 = np.array([1 - yR, yR, 0.0, 0.0])

        Tpre = round(1 / sigma)

        burn_in = simulate_core(
            4, K, psi, x0, y0, Wm, Wf, Mu, S, H, Rm, alpha, Tpre, Gauss,
            test_allele, float("inf"), rng,
        )

        xR = float(burn_in.x[_R, -1])
        yR = float(burn_in.y[_R, -1])

        x0 = np.array([1 - xD - xR, xR, 0.0, xD])
        y0 = np.array([1 - yD - yR, yR, 0.0, yD])
    else:
        x0 = np.array([1 - xD, 0.0, 0.0, xD])
        y0 = np.array([1 - yD, 0.0, 0.0, yD])

    if np.any(x0 < 0) or np.any(y0 < 0):
        raise ValueError("Error: frequency vector must not have negative entries")

    result = simulate_core(
        4, K, psi, x0, y0, Wm, Wf, Mu, S, H, Rm, alpha, T, Gauss,
        test_allele, test_threshold, rng,
    )

    return result
