"""Core Wright-Fisher / Beverton-Holt simulation loop.

This is a Python port of ``TargetSiteResistanceSims_while.m`` from the
original MATLAB reference implementation
(https://github.com/BhavKhatri/MutliplexDriveResistanceSims). It drives a
single stochastic simulation of a dioecious (separate-sex) population subject
to viability selection, mutation, and multiplex gene-drive conversion, with
Beverton-Holt density-dependent population regulation.

MATLAB uses 1-based indexing throughout the reference implementation; this
port uses 0-based indexing everywhere, including for the ``H`` (drive
heterozygote) index array, which callers must supply already converted to
0-based indices.

Note on naming: the original MATLAB function signature begins with ``K``
(the *number of alleles*), which is easily confused with the *carrying
capacity* (also often called ``K`` in the biology). To avoid that ambiguity
this port names that argument ``num_alleles`` and reserves ``alpha`` for the
Beverton-Holt density-dependence parameter (as in the original).
"""

from __future__ import annotations

from typing import List, Sequence, Tuple

import numpy as np

from ._types import SimulationResult
from .sampler import gauss_poisson_hybrid_mnrnd

__all__ = ["simulate_core", "allele_frequency_update", "wright_fisher_sampling"]


def allele_frequency_update(
    xt: np.ndarray,
    yt: np.ndarray,
    Wm: np.ndarray,
    Wf: np.ndarray,
    wm: float,
    wf: float,
    Mu: np.ndarray,
    H: np.ndarray,
    S: np.ndarray,
) -> Tuple[np.ndarray, np.ndarray]:
    """Update allele frequencies for one generation (viability selection,
    mutation and drive), following ``AlleleFrequencyUpdate`` in the MATLAB
    reference code.

    ``H`` must be a ``(2, Nhz)`` 0-based integer array whose columns give the
    pair of allele indices involved in each drive heterozygote (the drive
    allele is conventionally the second row).
    """
    num_alleles = xt.shape[0]
    I = np.eye(num_alleles)

    if wm == 0:
        xx = np.zeros(num_alleles)
    else:
        xx = 0.5 * (I + Mu) @ ((Wm @ xt) * yt + (Wm @ yt) * xt) / wm

    if wf == 0:
        yy = np.zeros(num_alleles)
    else:
        yy = 0.5 * (I + Mu) @ ((Wf @ yt) * xt + (Wf @ xt) * yt) / wf

    drivem = np.zeros(num_alleles)
    drivef = np.zeros(num_alleles)

    Nhz = H.shape[1]
    for j in range(Nhz):
        h1 = int(H[0, j])
        h2 = int(H[1, j])

        hzfreq = xt[h1] * yt[h2] + xt[h2] * yt[h1]
        mut = 1.0 + Mu[h1, h1]

        if wm != 0:
            drivem = drivem + 0.5 * mut * S[:, j] * Wm[h1, h2] / wm * hzfreq
        if wf != 0:
            drivef = drivef + 0.5 * mut * S[:, j] * Wf[h1, h2] / wf * hzfreq

    xx = xx + drivem
    yy = yy + drivef

    return xx, yy


def wright_fisher_sampling(
    zz: np.ndarray,
    NN: int,
    Gauss: bool,
    rng: np.random.Generator,
) -> np.ndarray:
    """Draw a new population from a combined male/female allele frequency
    vector ``zz`` (which need not be exactly normalised), following
    ``WrightFisherSampling`` in the MATLAB reference code.
    """
    if np.any(zz < 0):
        raise ValueError("Error: frequency vector must not have negative entries")

    zz = zz / zz.sum()

    if Gauss:
        nn = gauss_poisson_hybrid_mnrnd(NN, zz, rng)
    else:
        nn = rng.multinomial(NN, zz)

    return nn


def _end_condition(
    x_k: np.ndarray,
    y_k: np.ndarray,
    test_allele: Sequence[int],
    test_threshold: float,
    U: int,
) -> bool:
    """Return True if the resistance/establishment threshold has been met at
    the current generation, following the three ``numel(test_allele)``
    branches in the MATLAB reference code.
    """
    if U == 2:
        return False

    if len(test_allele) < 2:
        a = test_allele[0]
        return bool(x_k[a] >= test_threshold and y_k[a] >= test_threshold)

    if len(test_allele) == 2:
        a, b = test_allele
        cond1 = x_k[a] >= test_threshold and y_k[a] >= test_threshold
        cond2 = x_k[b] >= test_threshold and y_k[b] >= test_threshold
        return bool(cond1 or cond2)

    xr = sum(x_k[a] for a in test_allele)
    yr = sum(y_k[a] for a in test_allele)
    return bool(xr > test_threshold and yr > test_threshold)


def simulate_core(
    num_alleles: int,
    N0: float,
    psi: float,
    x0: np.ndarray,
    y0: np.ndarray,
    Wm: np.ndarray,
    Wf: np.ndarray,
    Mu: np.ndarray,
    S: np.ndarray,
    H: np.ndarray,
    Rm: float,
    alpha: float,
    T: int,
    Gauss: bool,
    test_allele: Sequence[int],
    test_threshold: float,
    rng: np.random.Generator,
) -> SimulationResult:
    """Run a single stochastic simulation, porting
    ``TargetSiteResistanceSims_while.m``.

    Parameters mirror the MATLAB function of the same name, with ``K``
    renamed to ``num_alleles`` to disambiguate it from carrying capacity, and
    ``driveheterozgotes``/``stoichiometry`` renamed to ``H``/``S`` (as in the
    original body of the function). ``H`` must already be 0-based.
    """
    x0 = np.asarray(x0, dtype=float)
    y0 = np.asarray(y0, dtype=float)

    if x0.shape[0] != num_alleles or y0.shape[0] != num_alleles:
        raise ValueError(
            "Length of initial vectors x0, y0 should be == number of alleles"
        )

    M0 = psi * N0
    F0 = (1 - psi) * N0

    x_cols: List[np.ndarray] = [x0.copy()]
    y_cols: List[np.ndarray] = [y0.copy()]
    z_cols: List[np.ndarray] = [
        np.concatenate([x0 * M0 / N0, y0 * F0 / N0]) if N0 != 0 else np.zeros(2 * num_alleles)
    ]
    M_list: List[float] = [M0]
    F_list: List[float] = [F0]
    N_list: List[float] = [N0]
    wm_list: List[float] = []
    wf_list: List[float] = []

    U = 0
    establishment = 0

    # ``k`` below always mirrors MATLAB's 1-based column index of the
    # generation just written (``k = len(x_cols)``), so no manual counter
    # needs to be threaded through the loop.
    while U != 1:
        xt = x_cols[-1]
        yt = y_cols[-1]
        Ft = F_list[-1]
        Nt = N_list[-1]

        wm = float(yt @ Wm @ xt)
        wf = float(xt @ Wf @ yt)

        wm_list.append(wm)
        wf_list.append(wf)

        if Ft == 0:
            FF = 0.0
            MM = 0.0
        else:
            # NOTE: both FF (expected female offspring) and MM (expected male
            # offspring) use the *female* mean fitness wf, not wm. This exactly
            # matches the MATLAB reference (TargetSiteResistanceSims_while.m),
            # which explicitly overrides an earlier `MM = Rm*wm*Ft/...` with
            # `MM = Rm*wf*Ft/...` (the wm-based line is left commented out in
            # the source) -- i.e. this is a deliberate modelling choice in the
            # original model (only mated females, weighted by their fitness,
            # determine total offspring number for both sexes), not a bug.
            FF = Rm * wf * Ft / (1 + Nt / alpha)
            MM = Rm * wf * Ft / (1 + Nt / alpha)

        NN_expected = MM + FF
        NN = int(rng.poisson(NN_expected)) if NN_expected > 0 else 0

        if NN != 0:
            xx, yy = allele_frequency_update(xt, yt, Wm, Wf, wm, wf, Mu, H, S)
            zz = np.concatenate([xx / 2, yy / 2])

            nn = wright_fisher_sampling(zz, NN, Gauss, rng)

            M_new = float(nn[:num_alleles].sum())
            F_new = float(nn[num_alleles:].sum())

            x_new = np.zeros(num_alleles) if M_new == 0 else nn[:num_alleles] / M_new
            y_new = np.zeros(num_alleles) if F_new == 0 else nn[num_alleles:] / F_new

            x_cols.append(x_new)
            y_cols.append(y_new)
            z_cols.append(nn / NN)
            M_list.append(M_new)
            F_list.append(F_new)
            N_list.append(float(NN))

            k = len(x_cols)

            if _end_condition(x_new, y_new, test_allele, test_threshold, U):
                U = 2
                T = round(k * 1.5)
                establishment = 1
            elif k == T + 1:
                if U != 2:
                    establishment = 0
                    U = 1
                else:
                    U = 1
            # else: continue the loop -- nothing further to do.
        else:
            # Population extinct: mirrors the untouched (zero) preallocated
            # column in the MATLAB implementation.
            x_cols.append(np.zeros(num_alleles))
            y_cols.append(np.zeros(num_alleles))
            z_cols.append(np.zeros(2 * num_alleles))
            M_list.append(0.0)
            F_list.append(0.0)
            N_list.append(0.0)
            U = 1
            establishment = 0

    x = np.array(x_cols).T
    y = np.array(y_cols).T
    z = np.array(z_cols).T
    M = np.array(M_list)
    F = np.array(F_list)
    N = np.array(N_list)

    # Pad wm/wf to align 1:1 with the recorded generations (the last
    # generation has no "outgoing" fitness value recorded).
    while len(wm_list) < len(N):
        wm_list.append(np.nan)
        wf_list.append(np.nan)
    wm_arr = np.array(wm_list)
    wf_arr = np.array(wf_list)

    x[:, M == 0] = np.nan
    y[:, F == 0] = np.nan
    wm_arr[(M == 0) | (F == 0)] = np.nan
    wf_arr[(M == 0) | (F == 0)] = np.nan

    t = np.arange(len(N))

    resistance = establishment
    N_end = float(N[-1])
    tau = int(t[-1])

    return SimulationResult(
        resistance=resistance,
        N_end=N_end,
        tau=tau,
        x=x,
        y=y,
        t=t,
        M=M,
        F=F,
        N=N,
        wm=wm_arr,
        wf=wf_arr,
        z=z,
    )
