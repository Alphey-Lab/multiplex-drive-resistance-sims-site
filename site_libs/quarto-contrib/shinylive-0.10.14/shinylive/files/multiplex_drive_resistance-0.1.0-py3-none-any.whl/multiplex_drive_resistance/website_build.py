"""Build helpers for the Quarto/Shinylive website."""

from __future__ import annotations

import argparse
import re
import shutil
from pathlib import Path

WHEEL_GLOB = "multiplex_drive_resistance-*.whl"
REQUIREMENT_TOKEN = "__BROWSER_WHEEL_REQUIREMENT__"
REQUIREMENTS_MARKER = "## file: requirements.txt"
DEFAULT_WHEELS_DIR = Path("website/files")
DEFAULT_TEMPLATE_PATH = Path("website/index.qmd.in")
DEFAULT_QMD_PATH = Path("website/index.qmd")
DEFAULT_SITE_DIR = Path("_site")
DEFAULT_RENDERED_HTML = DEFAULT_SITE_DIR / "website" / "index.html"
SHINYLIVE_RUNTIME_GLOB = "site_libs/quarto-contrib/shinylive-*/shinylive"


def find_browser_wheel(wheels_dir: Path = DEFAULT_WHEELS_DIR) -> Path:
    """Return the single browser wheel built for the Shinylive app."""
    matches = sorted(path for path in wheels_dir.glob(WHEEL_GLOB) if path.is_file())
    if len(matches) != 1:
        raise ValueError(
            f"Expected exactly one browser wheel matching {WHEEL_GLOB!r} in {wheels_dir}, found {len(matches)}."
        )
    return matches[0]


def browser_wheel_requirement(wheels_dir: Path = DEFAULT_WHEELS_DIR) -> str:
    """Return the relative wheel requirement used by the browser app."""
    return f"./files/{find_browser_wheel(wheels_dir).name}"


def render_website_index(
    template_path: Path = DEFAULT_TEMPLATE_PATH,
    output_path: Path = DEFAULT_QMD_PATH,
    wheels_dir: Path = DEFAULT_WHEELS_DIR,
) -> Path:
    """Render the Quarto source document with the current wheel requirement."""
    template = template_path.read_text(encoding="utf-8")
    if REQUIREMENT_TOKEN not in template:
        raise ValueError(f"Template {template_path} does not contain the {REQUIREMENT_TOKEN!r} placeholder.")

    rendered = template.replace(REQUIREMENT_TOKEN, browser_wheel_requirement(wheels_dir))
    output_path.write_text(rendered, encoding="utf-8")
    return output_path


def find_shinylive_runtime_dir(site_dir: Path = DEFAULT_SITE_DIR) -> Path:
    """Return the single rendered Shinylive runtime directory."""
    matches = sorted(path for path in site_dir.glob(SHINYLIVE_RUNTIME_GLOB) if path.is_dir())
    if len(matches) != 1:
        raise ValueError(
            f"Expected exactly one Shinylive runtime directory matching {SHINYLIVE_RUNTIME_GLOB!r} in {site_dir}, "
            f"found {len(matches)}."
        )
    return matches[0]


def _copy_wheel_into_directory(wheel: Path, destination_dir: Path) -> Path:
    destination_dir.mkdir(parents=True, exist_ok=True)

    for stale_wheel in destination_dir.glob(WHEEL_GLOB):
        if stale_wheel.name != wheel.name:
            stale_wheel.unlink()

    destination_path = destination_dir / wheel.name
    shutil.copy2(wheel, destination_path)
    return destination_path


def copy_browser_wheel_to_site(
    wheels_dir: Path = DEFAULT_WHEELS_DIR,
    site_dir: Path = DEFAULT_SITE_DIR,
) -> tuple[Path, Path]:
    """Copy the current browser wheel into the rendered site tree and Shinylive runtime."""
    wheel = find_browser_wheel(wheels_dir)
    public_destination = _copy_wheel_into_directory(wheel, site_dir / "website" / "files")
    runtime_destination = _copy_wheel_into_directory(wheel, find_shinylive_runtime_dir(site_dir) / "files")
    return public_destination, runtime_destination


def _requirements_block_matches(text: str, requirement: str) -> bool:
    pattern = re.compile(rf"{re.escape(REQUIREMENTS_MARKER)}\s+{re.escape(requirement)}(?:\s|<|&|\"|'|$)")
    return pattern.search(text) is not None


def validate_rendered_website(
    wheels_dir: Path = DEFAULT_WHEELS_DIR,
    qmd_path: Path = DEFAULT_QMD_PATH,
    rendered_html_path: Path = DEFAULT_RENDERED_HTML,
    site_dir: Path = DEFAULT_SITE_DIR,
) -> Path:
    """Validate that the rendered site and Shinylive app reference the current wheel."""
    wheel = find_browser_wheel(wheels_dir)
    requirement = f"./files/{wheel.name}"
    public_site_wheel = site_dir / "website" / "files" / wheel.name
    runtime_site_wheel = find_shinylive_runtime_dir(site_dir) / "files" / wheel.name

    if not public_site_wheel.is_file():
        raise ValueError(f"Rendered site is missing the public browser wheel asset at {public_site_wheel}.")

    if not runtime_site_wheel.is_file():
        raise ValueError(f"Rendered Shinylive runtime is missing the browser wheel asset at {runtime_site_wheel}.")

    qmd_text = qmd_path.read_text(encoding="utf-8")
    if not _requirements_block_matches(qmd_text, requirement):
        raise ValueError(f"{qmd_path} does not reference the current browser wheel requirement {requirement!r}.")

    rendered_html = rendered_html_path.read_text(encoding="utf-8")
    if "await micropip.install" in rendered_html:
        raise ValueError("Rendered Shinylive app still contains a bare top-level 'await micropip.install(...)'.")

    if not _requirements_block_matches(rendered_html, requirement):
        raise ValueError(
            f"Rendered Shinylive app does not reference the current browser wheel requirement {requirement!r}."
        )

    return runtime_site_wheel


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    subparsers = parser.add_subparsers(dest="command", required=True)

    prepare_parser = subparsers.add_parser("prepare-qmd", help="Render website/index.qmd from the template.")
    prepare_parser.add_argument("--template", type=Path, default=DEFAULT_TEMPLATE_PATH)
    prepare_parser.add_argument("--output", type=Path, default=DEFAULT_QMD_PATH)
    prepare_parser.add_argument("--wheels-dir", type=Path, default=DEFAULT_WHEELS_DIR)

    copy_parser = subparsers.add_parser("copy-wheel", help="Copy the built wheel into the rendered site.")
    copy_parser.add_argument("--wheels-dir", type=Path, default=DEFAULT_WHEELS_DIR)
    copy_parser.add_argument("--site-dir", type=Path, default=DEFAULT_SITE_DIR)

    validate_parser = subparsers.add_parser("validate-render", help="Validate the rendered wheel asset and app.")
    validate_parser.add_argument("--wheels-dir", type=Path, default=DEFAULT_WHEELS_DIR)
    validate_parser.add_argument("--qmd", type=Path, default=DEFAULT_QMD_PATH)
    validate_parser.add_argument("--rendered-html", type=Path, default=DEFAULT_RENDERED_HTML)
    validate_parser.add_argument("--site-dir", type=Path, default=DEFAULT_SITE_DIR)

    return parser


def main() -> None:
    """Run the requested website build helper command."""
    parser = _build_parser()
    args = parser.parse_args()

    if args.command == "prepare-qmd":
        output_path = render_website_index(args.template, args.output, args.wheels_dir)
        print(f"Rendered {output_path} with requirement {browser_wheel_requirement(args.wheels_dir)}")
    elif args.command == "copy-wheel":
        public_path, runtime_path = copy_browser_wheel_to_site(args.wheels_dir, args.site_dir)
        print(f"Copied browser wheel to {public_path} and {runtime_path}")
    elif args.command == "validate-render":
        site_wheel = validate_rendered_website(args.wheels_dir, args.qmd, args.rendered_html, args.site_dir)
        print(f"Validated rendered browser wheel asset {site_wheel}")
    else:
        parser.error(f"Unsupported command {args.command!r}.")


if __name__ == "__main__":
    main()
